# FeedbackIQ

FeedbackIQ is an AI-assisted customer feedback portal that turns submitted reviews into sentiment, emotion, keyword, trend, and executive-report insights.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/feedback-iq run dev` — run the FeedbackIQ web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/feedback-iq/src/App.tsx` — route map and shared app provider setup
- `artifacts/feedback-iq/src/components/feedback-ui.tsx` — dashboard, inbox, submit, reports, settings, and demo access screens
- `artifacts/feedback-iq/src/index.css` — FeedbackIQ visual theme and utility styles
- `artifacts/api-server/src/routes/feedback.ts` — feedback, dashboard, and report API routes
- `artifacts/api-server/src/lib/feedback-analysis.ts` — deterministic local sentiment, emotion, and keyword analyzer
- `lib/api-spec/openapi.yaml` — source of truth for the generated client and Zod API schemas
- `lib/db/src/schema/feedback.ts` — PostgreSQL schema for feedback and reports

## Architecture decisions

- OpenAPI is the shared contract; the frontend consumes generated React Query hooks and the API validates generated Zod schemas.
- Feedback analysis is deterministic and local for a working first-run experience; the analysis module is isolated for a future AI provider.
- Demo access screens and role preview are intentionally credential-free for the first build; no local password store was added.
- Seed data is created lazily on the first feedback/report read so the dashboard is useful immediately in a new database.

## Product

- Overview dashboard with aggregate metrics, sentiment mix, trend visualization, AI watchlist, and latest customer voice
- Filterable feedback inbox with search, sentiment/team filters, full classifier readout, and delete flow
- Customer feedback submission with star rating and server-side sentiment analysis
- Executive report generation and plain-text download
- Settings, role preview, demo sign-in, and demo sign-up screens

## User preferences

- The user asked for a complete frontend and backend implementation based on the FeedbackIQ specification.

## Gotchas

- Artifact builds require `PORT` and `BASE_PATH`; the managed workflow supplies them automatically.
- Regenerate API client and Zod output after changing `lib/api-spec/openapi.yaml`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

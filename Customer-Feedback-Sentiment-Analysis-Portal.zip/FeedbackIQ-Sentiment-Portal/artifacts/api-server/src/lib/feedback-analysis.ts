type Sentiment = "Positive" | "Neutral" | "Negative";

const positiveWords = [
  "excellent",
  "great",
  "love",
  "helpful",
  "friendly",
  "fast",
  "smooth",
  "happy",
  "easy",
  "impressive",
  "perfect",
  "good",
  "satisfied",
];

const negativeWords = [
  "poor",
  "bad",
  "late",
  "delay",
  "delayed",
  "slow",
  "angry",
  "frustrated",
  "broken",
  "issue",
  "problem",
  "refund",
  "unhelpful",
  "disappointed",
];

const emotionWords: Array<[string, string]> = [
  ["excited", "Excited"],
  ["love", "Happy"],
  ["happy", "Happy"],
  ["angry", "Angry"],
  ["frustrated", "Frustrated"],
  ["disappointed", "Frustrated"],
  ["satisfied", "Satisfied"],
];

const stopWords = new Set([
  "about",
  "after",
  "again",
  "also",
  "been",
  "could",
  "from",
  "have",
  "into",
  "just",
  "really",
  "that",
  "their",
  "there",
  "they",
  "this",
  "very",
  "were",
  "with",
  "would",
  "your",
]);

export function analyzeFeedback(message: string, rating: number): {
  sentiment: Sentiment;
  sentimentScore: number;
  emotion: string;
  keywords: string[];
} {
  const normalized = message.toLowerCase();
  const tokens = normalized.match(/[a-z]{3,}/g) ?? [];
  const positiveHits = tokens.filter((token) => positiveWords.includes(token)).length;
  const negativeHits = tokens.filter((token) => negativeWords.includes(token)).length;
  const ratingSignal = (rating - 3) / 2;
  const lexicalSignal = Math.max(-1, Math.min(1, (positiveHits - negativeHits) / 3));
  const sentimentScore = Number((ratingSignal * 0.65 + lexicalSignal * 0.35).toFixed(2));
  const sentiment: Sentiment =
    sentimentScore > 0.2 ? "Positive" : sentimentScore < -0.2 ? "Negative" : "Neutral";
  const emotion =
    emotionWords.find(([word]) => normalized.includes(word))?.[1] ??
    (sentiment === "Positive" ? "Satisfied" : sentiment === "Negative" ? "Frustrated" : "Neutral");
  const keywords = Array.from(
    new Set(tokens.filter((token) => !stopWords.has(token) && token.length > 4)),
  ).slice(0, 5);

  return {
    sentiment,
    sentimentScore,
    emotion,
    keywords: keywords.length > 0 ? keywords : ["customer voice"],
  };
}
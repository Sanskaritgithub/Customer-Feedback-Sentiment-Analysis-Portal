import { Router, type IRouter } from "express";
import { count, desc, eq } from "drizzle-orm";
import { db, feedbackTable, reportsTable } from "@workspace/db";
import {
  CreateFeedbackBody,
  CreateFeedbackResponse,
  CreateReportBody,
  CreateReportResponse,
  DeleteFeedbackParams,
  GetDashboardInsightsResponse,
  GetDashboardOverviewResponse,
  GetDashboardTrendsResponse,
  GetFeedbackParams,
  GetFeedbackResponse,
  ListFeedbackQueryParams,
  ListFeedbackResponse,
  ListReportsResponse,
} from "@workspace/api-zod";
import { analyzeFeedback } from "../lib/feedback-analysis";

const router: IRouter = Router();
let seedPromise: Promise<void> | undefined;

function toFeedbackResponse(record: typeof feedbackTable.$inferSelect) {
  return {
    ...record,
    createdAt: record.createdAt.toISOString(),
  };
}

async function ensureSeedData(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [{ value }] = await db.select({ value: count() }).from(feedbackTable);
      if (Number(value) > 0) {
        return;
      }

      const examples = [
        {
          customerName: "Aisha Rao",
          email: "aisha@example.com",
          department: "Support",
          product: "Priority support",
          rating: 5,
          message: "The support team was excellent and very helpful. My issue was solved fast.",
        },
        {
          customerName: "Lucas Meyer",
          email: "lucas@example.com",
          department: "Delivery",
          product: "Express delivery",
          rating: 2,
          message: "The delivery was delayed and tracking updates were slow.",
        },
        {
          customerName: "Meera Shah",
          email: "meera@example.com",
          department: "Product",
          product: "Workspace",
          rating: 4,
          message: "The workspace is easy to use and the new reporting tools are impressive.",
        },
        {
          customerName: "Jon Bell",
          email: "jon@example.com",
          department: "Billing",
          product: "Annual plan",
          rating: 3,
          message: "The plan is okay overall. Billing details could be clearer.",
        },
        {
          customerName: "Sana Iyer",
          email: "sana@example.com",
          department: "Support",
          product: "Live chat",
          rating: 5,
          message: "I love how friendly the live chat team is. Great experience.",
        },
      ];

      await db.insert(feedbackTable).values(
        examples.map((example) => ({
          ...example,
          ...analyzeFeedback(example.message, example.rating),
        })),
      );

      const [{ reportCount }] = await db.select({ reportCount: count() }).from(reportsTable);
      if (Number(reportCount) === 0) {
        await db.insert(reportsTable).values({
          reportName: "Customer voice — June 2026",
          summary: "Customers are broadly satisfied, with delivery delays emerging as the clearest opportunity to improve.",
          highlights: [
            "Positive sentiment leads the sample with a 60% share.",
            "Delivery-related feedback is the most common negative theme.",
            "Support earns the strongest average rating across departments.",
          ],
        });
      }
    })();
  }
  await seedPromise;
}

async function getAllFeedback() {
  await ensureSeedData();
  return db.select().from(feedbackTable).orderBy(desc(feedbackTable.createdAt));
}

router.get("/feedback", async (req, res): Promise<void> => {
  const parsed = ListFeedbackQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const records = await getAllFeedback();
  const filtered = records.filter((record) => {
    if (parsed.data.sentiment && record.sentiment !== parsed.data.sentiment) {
      return false;
    }
    if (
      parsed.data.department &&
      record.department.toLowerCase() !== parsed.data.department.toLowerCase()
    ) {
      return false;
    }
    return true;
  });
  res.json(ListFeedbackResponse.parse(filtered.slice(0, parsed.data.limit).map(toFeedbackResponse)));
});

router.post("/feedback", async (req, res): Promise<void> => {
  const parsed = CreateFeedbackBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const analysis = analyzeFeedback(parsed.data.message, parsed.data.rating);
  const [created] = await db
    .insert(feedbackTable)
    .values({ ...parsed.data, ...analysis })
    .returning();
  res.status(201).json(CreateFeedbackResponse.parse(toFeedbackResponse(created)));
});

router.get("/feedback/:id", async (req, res): Promise<void> => {
  const parsed = GetFeedbackParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await ensureSeedData();
  const [record] = await db
    .select()
    .from(feedbackTable)
    .where(eq(feedbackTable.id, parsed.data.id));
  if (!record) {
    res.status(404).json({ error: "Feedback not found" });
    return;
  }
  res.json(GetFeedbackResponse.parse(toFeedbackResponse(record)));
});

router.delete("/feedback/:id", async (req, res): Promise<void> => {
  const parsed = DeleteFeedbackParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [deleted] = await db
    .delete(feedbackTable)
    .where(eq(feedbackTable.id, parsed.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Feedback not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/dashboard/overview", async (_req, res): Promise<void> => {
  const records = await getAllFeedback();
  const totalFeedback = records.length;
  const positiveReviews = records.filter((record) => record.sentiment === "Positive").length;
  const negativeReviews = records.filter((record) => record.sentiment === "Negative").length;
  const neutralReviews = records.filter((record) => record.sentiment === "Neutral").length;
  const averageRating =
    totalFeedback === 0
      ? 0
      : Number((records.reduce((sum, record) => sum + record.rating, 0) / totalFeedback).toFixed(1));
  const percent = (value: number) =>
    totalFeedback === 0 ? 0 : Math.round((value / totalFeedback) * 100);
  const response = {
    totalFeedback,
    positiveReviews,
    negativeReviews,
    neutralReviews,
    averageRating,
    positivePercent: percent(positiveReviews),
    neutralPercent: percent(neutralReviews),
    negativePercent: percent(negativeReviews),
    latestFeedback: toFeedbackResponse(records[0]),
  };
  res.json(GetDashboardOverviewResponse.parse(response));
});

router.get("/dashboard/trends", async (_req, res): Promise<void> => {
  const records = await getAllFeedback();
  const groups = new Map<string, { total: number; positive: number; negative: number; neutral: number }>();
  for (const record of records) {
    const month = record.createdAt.toLocaleString("en-US", { month: "short" });
    const group = groups.get(month) ?? { total: 0, positive: 0, negative: 0, neutral: 0 };
    group.total += 1;
    group[record.sentiment.toLowerCase() as "positive" | "negative" | "neutral"] += 1;
    groups.set(month, group);
  }
  const trend = Array.from(groups.entries()).reverse().map(([month, group]) => ({ month, ...group }));
  res.json(GetDashboardTrendsResponse.parse(trend));
});

router.get("/dashboard/insights", async (_req, res): Promise<void> => {
  const records = await getAllFeedback();
  const negative = records.filter((record) => record.sentiment === "Negative").length;
  const positive = records.filter((record) => record.sentiment === "Positive").length;
  const deliveryIssues = records.filter(
    (record) => record.message.toLowerCase().includes("deliver") || record.department === "Delivery",
  ).length;
  const insights = [
    {
      id: "sentiment-health",
      title: positive >= negative ? "Customer sentiment is trending healthy" : "Negative sentiment needs attention",
      detail:
        positive >= negative
          ? "Positive feedback currently outweighs negative feedback across the workspace."
          : "Negative feedback is closing the gap. Review the most recent complaints this week.",
      tone: positive >= negative ? "positive" : "warning",
      metric: `${Math.round((positive / Math.max(records.length, 1)) * 100)}% positive`,
    },
    {
      id: "delivery-pattern",
      title: "Delivery is the clearest friction point",
      detail: "Customers mention timing and tracking more often than any other operational theme.",
      tone: deliveryIssues > 1 ? "warning" : "neutral",
      metric: `${deliveryIssues} related mentions`,
    },
    {
      id: "support-strength",
      title: "Support is building trust",
      detail: "Helpful and friendly language appears repeatedly in the highest-rated interactions.",
      tone: "positive",
      metric: `${records.filter((record) => record.department === "Support").length} support notes`,
    },
  ];
  res.json(GetDashboardInsightsResponse.parse(insights));
});

router.get("/reports", async (_req, res): Promise<void> => {
  await ensureSeedData();
  const reports = await db.select().from(reportsTable).orderBy(desc(reportsTable.generatedDate));
  res.json(
    ListReportsResponse.parse(
      reports.map((report) => ({ ...report, generatedDate: report.generatedDate.toISOString() })),
    ),
  );
});

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = CreateReportBody.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const records = await getAllFeedback();
  const positive = records.filter((record) => record.sentiment === "Positive").length;
  const total = Math.max(records.length, 1);
  const reportName =
    parsed.data.reportName?.trim() || `Customer voice — ${new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}`;
  const [report] = await db
    .insert(reportsTable)
    .values({
      reportName,
      summary: `${Math.round((positive / total) * 100)}% of analyzed feedback is positive. Delivery timing and support responsiveness are the clearest themes to monitor.`,
      highlights: [
        `${records.length} feedback records analyzed`,
        `${Math.round((positive / total) * 100)}% positive sentiment`,
        `Average rating ${(
          records.reduce((sum, record) => sum + record.rating, 0) / total
        ).toFixed(1)} / 5`,
      ],
    })
    .returning();
  res.status(201).json(
    CreateReportResponse.parse({ ...report, generatedDate: report.generatedDate.toISOString() }),
  );
});

export default router;
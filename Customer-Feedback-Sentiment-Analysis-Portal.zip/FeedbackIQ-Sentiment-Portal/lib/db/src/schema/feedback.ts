import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  real,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const feedbackTable = pgTable("feedback", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  email: text("email").notNull(),
  department: text("department").notNull(),
  product: text("product").notNull(),
  rating: integer("rating").notNull(),
  message: text("message").notNull(),
  sentiment: text("sentiment").notNull(),
  sentimentScore: real("sentiment_score").notNull(),
  emotion: text("emotion").notNull(),
  keywords: text("keywords").array().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertFeedbackSchema = createInsertSchema(feedbackTable).omit({
  id: true,
  createdAt: true,
  sentiment: true,
  sentimentScore: true,
  emotion: true,
  keywords: true,
});

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type FeedbackRecord = typeof feedbackTable.$inferSelect;

export const reportsTable = pgTable("reports", {
  id: serial("id").primaryKey(),
  reportName: text("report_name").notNull(),
  generatedDate: timestamp("generated_date", { withTimezone: true })
    .defaultNow()
    .notNull(),
  summary: text("summary").notNull(),
  highlights: text("highlights").array().notNull(),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({
  id: true,
  generatedDate: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type ReportRecord = typeof reportsTable.$inferSelect;